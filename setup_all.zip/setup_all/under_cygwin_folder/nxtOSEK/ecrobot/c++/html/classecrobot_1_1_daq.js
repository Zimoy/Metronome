var classecrobot_1_1_daq =
[
    [ "Daq", "classecrobot_1_1_daq.html#aeac21733f6fbc3b91af3c750e95b38ac", null ],
    [ "send", "classecrobot_1_1_daq.html#ac7daef95d805e45610e4ff851a957f30", null ],
    [ "send", "classecrobot_1_1_daq.html#ab30846e51d18ad4e5c04aa0b95c64098", null ]
];