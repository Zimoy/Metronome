function ret = ver_nxtOSEK()

% VER_NXTOSEK
% this info is used for only Embedded Coder Robot NXT installation.
%

ret = 2.18;

%end of file
