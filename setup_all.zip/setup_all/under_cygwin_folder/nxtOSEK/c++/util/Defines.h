#ifndef _DEFINES_H_
#define _DEFINES_H_

#define NXT_LCD_DEPTH 8
#define NXT_LCD_WIDTH 100

#endif

