var searchData=
[
  ['upperleftx',['upperLeftX',['../structecrobot_1_1_camera_1_1_rectangle___t.html#a60ad108d517c65a89fac19eaef9d0f78',1,'ecrobot::Camera::Rectangle_T']]],
  ['upperlefty',['upperLeftY',['../structecrobot_1_1_camera_1_1_rectangle___t.html#a2143c30e59f5efc869d40dab8f504f8e',1,'ecrobot::Camera::Rectangle_T']]]
];
