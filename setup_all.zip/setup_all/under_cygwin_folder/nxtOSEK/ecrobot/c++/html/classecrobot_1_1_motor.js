var classecrobot_1_1_motor =
[
    [ "Motor", "classecrobot_1_1_motor.html#a38a8e8791e611d2c3c3a40123e273f7f", null ],
    [ "~Motor", "classecrobot_1_1_motor.html#a536af26810bbef9648cf7e0aefade2f9", null ],
    [ "getBrake", "classecrobot_1_1_motor.html#aec8784aa36395b92bb057bb32db61116", null ],
    [ "getCount", "classecrobot_1_1_motor.html#a15d41c791b36c664a3b1859287e42d6d", null ],
    [ "getPort", "classecrobot_1_1_motor.html#aeac18794b4f0a65c7d0e57e3daecaae7", null ],
    [ "getPWM", "classecrobot_1_1_motor.html#a0c9af813be904a4d5d673dbba35e5474", null ],
    [ "reset", "classecrobot_1_1_motor.html#a57652067fc790287a57ec97bdfc3534d", null ],
    [ "setBrake", "classecrobot_1_1_motor.html#ad74456fd87f78a58515378267e6b0c4a", null ],
    [ "setCount", "classecrobot_1_1_motor.html#a21d2e138fd6d8b0a51a0841174bd73cc", null ],
    [ "setPWM", "classecrobot_1_1_motor.html#a5fb13b21ff75be92f5272b5d5bbdf7a9", null ],
    [ "PWM_MAX", "classecrobot_1_1_motor.html#a22984ccdde00bc0209e730fd03e15299", null ],
    [ "PWM_MIN", "classecrobot_1_1_motor.html#a37dc14c03259151bbbdea23d0bdb884c", null ]
];