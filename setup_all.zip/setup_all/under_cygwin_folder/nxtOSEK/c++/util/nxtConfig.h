#ifndef _NXTCONFIG_H_
#define _NXTCONFIG_H_

#define NXT_ASSERT 1
#define NXT_WARN_ASSERT 1

#endif


