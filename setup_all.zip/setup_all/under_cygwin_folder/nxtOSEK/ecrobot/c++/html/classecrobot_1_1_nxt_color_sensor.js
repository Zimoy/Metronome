var classecrobot_1_1_nxt_color_sensor =
[
    [ "eColorNumber", "classecrobot_1_1_nxt_color_sensor.html#abcf759b1a84004c4f9b7fbe500328869", null ],
    [ "eSensorMode", "classecrobot_1_1_nxt_color_sensor.html#a5e615170e654b02c23d75d2c7382cac8", null ],
    [ "NxtColorSensor", "classecrobot_1_1_nxt_color_sensor.html#a786eee1dd3ad401d30a42a207f4c3fd8", null ],
    [ "~NxtColorSensor", "classecrobot_1_1_nxt_color_sensor.html#a0bf16dbc123a348757c11a641639a2eb", null ],
    [ "get", "classecrobot_1_1_nxt_color_sensor.html#a2a30c7b1c94aeeeb585bb77e521ce9f9", null ],
    [ "getBrightness", "classecrobot_1_1_nxt_color_sensor.html#a9aa3bce2fdff04308975000d9823872f", null ],
    [ "getColorNumber", "classecrobot_1_1_nxt_color_sensor.html#a6dbcd7104caf7dec858fe18f923e5857", null ],
    [ "getRawColor", "classecrobot_1_1_nxt_color_sensor.html#ad25fd1a7ee3fe5721d79cd932897e5f5", null ],
    [ "getSensorMode", "classecrobot_1_1_nxt_color_sensor.html#a27968a58a8827abb5520dbc00e95c649", null ],
    [ "processBackground", "classecrobot_1_1_nxt_color_sensor.html#a93f03affaf69a97105c8fe9e1034106c", null ],
    [ "setSensorMode", "classecrobot_1_1_nxt_color_sensor.html#a5b55d4d4510f5a595dc6beeb990bd180", null ]
];