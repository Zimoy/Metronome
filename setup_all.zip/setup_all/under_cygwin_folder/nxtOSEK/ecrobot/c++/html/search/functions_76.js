var searchData=
[
  ['vectort',['VectorT',['../structecrobot_1_1_vector_t.html#abddb1aba7be73157b76444603b8200b6',1,'ecrobot::VectorT::VectorT()'],['../structecrobot_1_1_vector_t.html#a637a631ac546af2d69bf11570b443b29',1,'ecrobot::VectorT::VectorT(T x, T y)']]]
];
