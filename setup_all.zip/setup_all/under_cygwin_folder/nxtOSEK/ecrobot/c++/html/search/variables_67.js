var searchData=
[
  ['get_5fcolor_5fmap',['GET_COLOR_MAP',['../classecrobot_1_1_camera.html#ab1fc098785e7814909c03ad0ecc24188',1,'ecrobot::Camera']]],
  ['get_5fversion',['GET_VERSION',['../classecrobot_1_1_camera.html#a2a3d489bb778b0d6884e6d49e2621cf5',1,'ecrobot::Camera']]]
];
