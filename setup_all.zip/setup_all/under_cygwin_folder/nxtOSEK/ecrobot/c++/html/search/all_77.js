var searchData=
[
  ['wait',['wait',['../classecrobot_1_1_clock.html#a7d4ae87221588d266c32f186cf482d3a',1,'ecrobot::Clock']]],
  ['waitforconnection',['waitForConnection',['../classecrobot_1_1_bluetooth.html#af1d5ce718aec21d45aabd6ec58a62072',1,'ecrobot::Bluetooth::waitForConnection(const CHAR *passkey, U32 duration)'],['../classecrobot_1_1_bluetooth.html#a811dfa4d84a38a5adabde1b978ebef0e',1,'ecrobot::Bluetooth::waitForConnection(const CHAR *passkey, const U8 address[7], U32 duration)']]],
  ['width',['width',['../structecrobot_1_1_camera_1_1_rectangle___t.html#a5f59ccad7d6202d910fa3810e1fa9cfa',1,'ecrobot::Camera::Rectangle_T']]],
  ['write_5fcam_5freg',['WRITE_CAM_REG',['../classecrobot_1_1_camera.html#a8ad5f2f41bbc0f86230d1295beef3913',1,'ecrobot::Camera']]]
];
